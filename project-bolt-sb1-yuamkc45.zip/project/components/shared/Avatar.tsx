import React from 'react';
import { View, Image, StyleSheet, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface AvatarProps {
  source: string | null;
  size?: number;
  style?: ViewStyle;
  withBorder?: boolean;
}

export default function Avatar({ 
  source, 
  size = 40, 
  style, 
  withBorder = false 
}: AvatarProps) {
  const containerStyle = {
    width: size,
    height: size,
    borderRadius: size / 2,
  };

  const defaultImage = 'https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg';
  const imageSource = source ? { uri: source } : { uri: defaultImage };

  if (withBorder) {
    return (
      <View style={[styles.borderContainer, containerStyle, style]}>
        <LinearGradient
          colors={['#FF4D67', '#FF8A5B']}
          style={[styles.gradientBorder, { padding: size * 0.05 }]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Image 
            source={imageSource} 
            style={[styles.image, { 
              width: size * 0.9, 
              height: size * 0.9, 
              borderRadius: (size * 0.9) / 2
            }]} 
          />
        </LinearGradient>
      </View>
    );
  }
  
  return (
    <View style={[styles.container, containerStyle, style]}>
      <Image source={imageSource} style={[styles.image, containerStyle]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
  },
  borderContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  gradientBorder: {
    borderRadius: 100,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});